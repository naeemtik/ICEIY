import { GoogleGenAI, GenerateContentResponse, Part } from "@google/genai";
import { Message } from '../types';

const API_KEY = process.env.API_KEY;
if (!API_KEY) {
  throw new Error("API_KEY environment variable not set");
}

const ai = new GoogleGenAI({ apiKey: API_KEY });

const CODE_SYSTEM_INSTRUCTION = `You are an expert web developer AI agent specializing in creating beautiful, modern, and functional websites.
Your task is to generate a complete, single \`index.html\` file based on the user's request, which may include an image or a video for context.

**Requirements:**
1.  **Single File:** The entire website must be contained in one \`index.html\` file.
2.  **Tailwind CSS:** You MUST use Tailwind CSS for all styling. Include it via the CDN: \`<script src="https://cdn.tailwindcss.com"></script>\`.
3.  **JavaScript:** All necessary JavaScript MUST be included within a \`<script>\` tag at the end of the \`<body>\`. Do not use external JS files.
4.  **Output Format:** Respond ONLY with the raw HTML code for the \`index.html\` file. Do NOT include any explanations, comments, or markdown formatting like \`\`\`html ... \`\`\` around the code. Your entire response should be the HTML content itself.
5.  **Placeholder Images:** You MUST use placeholder images from \`https://placehold.co\`. For example: \`<img src="https://placehold.co/600x400/27272a/FFFFFF?text=Placeholder" alt="A descriptive placeholder">\`. Adjust the size, colors, and text as needed to fit the design.

**Cloning & Modification:**
*   **Cloning from Image:** If the user provides an image, replicate its design as closely as possible, paying attention to layout, colors, and typography.
*   **Modification:** If the user provides existing code to modify, use it as the starting point and apply the requested changes, generating a complete new file.
*   **Element-Specific Modification:** If the user's request specifies a CSS selector for an element, you MUST apply the changes to that element. After making the change, ensure any selection-related attributes (like \`data-ai-agent-selected="true"\`) are removed from the final HTML output.
`;

const CHAT_SYSTEM_INSTRUCTION = `You are a helpful AI assistant integrated into a website development tool. Your name is Agent. Answer the user's questions clearly and concisely. If the user asks you to perform an action related to coding or website generation, politely guide them to phrase their request as a command (e.g., "Create a gallery page," "Change the button color to blue"). Keep your answers short and to the point. If the user uploads an image or video, analyze it and respond to their prompt.`;

const buildPromptParts = (chatHistory: Message[], customText?: string): Part[] => {
  const lastUserMessage = chatHistory.filter(m => m.role === 'user').pop();
  if (!lastUserMessage && !customText) return [];

  const content = customText || lastUserMessage?.content || '';
  const parts: Part[] = [{ text: content }];
  
  if (lastUserMessage?.image) {
    parts.unshift({
      inlineData: {
        mimeType: lastUserMessage.image.mimeType,
        data: lastUserMessage.image.data,
      },
    });
  }

  if (lastUserMessage?.video) {
    parts.unshift({
      inlineData: {
        mimeType: lastUserMessage.video.mimeType,
        data: lastUserMessage.video.data,
      },
    });
  }
  
  return parts;
};

export const generateWebsiteCodeStream = async (
  chatHistory: Message[], 
  currentCode: string, 
  isThinkingMode: boolean,
  debugErrors: string[] | null,
  selectedElementSelector: string | null,
): Promise<AsyncGenerator<GenerateContentResponse>> => {
  const lastUserMessage = chatHistory.filter(m => m.role === 'user').pop();
  
  let textPrompt: string;

  if (selectedElementSelector) {
     textPrompt = `The user has selected an element with the CSS selector \`${selectedElementSelector}\`.
  
Their modification request is: "${lastUserMessage?.content || ''}"

Apply this change to the selected element within the current code. The current code might have a \`data-ai-agent-selected="true"\` attribute on the element; remove this attribute in the final output.

Current Code:
\`\`\`html
${currentCode}
\`\`\`

Generate the complete, modified HTML file now.`;
  } else if (debugErrors && debugErrors.length > 0) {
    const userRequestText = lastUserMessage?.content ? `The user also made a request: "${lastUserMessage.content}"` : "This is an automatic fix attempt.";
    textPrompt = `The website code has produced JavaScript errors. Your primary task is to fix them. ${userRequestText}

Errors detected in the preview:
\`\`\`
${debugErrors.join('\n')}
\`\`\`

Here is the full current code of the website that needs to be fixed:
\`\`\`html
${currentCode}
\`\`\`

Generate the complete, new, and corrected HTML file now. Prioritize fixing the error above all else.`;
  } else {
    textPrompt = `The user wants to build or modify a website.
  
User Request: "${lastUserMessage?.content || ''}"
  
Current Code (use this as a starting point if it's not the initial placeholder):
\`\`\`html
${currentCode}
\`\`\`

Generate the complete HTML file now.`;
  }


  const parts: Part[] = buildPromptParts(chatHistory, textPrompt);

  let modelName: string;
  const config: any = {
    systemInstruction: CODE_SYSTEM_INSTRUCTION,
  };
  
  const useEffectiveModel = isThinkingMode || (debugErrors && debugErrors.length > 0) || !!selectedElementSelector;

  if (lastUserMessage?.video) {
    modelName = "gemini-2.5-pro";
    if (useEffectiveModel) {
      config.thinkingConfig = { thinkingBudget: 32768 };
    }
  } else {
    modelName = "gemini-flash-latest"; // Prioritize low-latency
    if (useEffectiveModel) {
      // flash supports thinking, let's use it to improve quality on complex tasks without sacrificing too much speed
      config.thinkingConfig = { thinkingBudget: 24576 };
    }
  }

  const response = await ai.models.generateContentStream({
    model: modelName,
    contents: { parts },
    config: config
  });

  return response;
};

export const getChatResponseStream = async (chatHistory: Message[]): Promise<AsyncGenerator<GenerateContentResponse>> => {
  const lastUserMessage = chatHistory.filter(m => m.role === 'user').pop();
  const parts = buildPromptParts(chatHistory);
  
  const modelName = lastUserMessage?.video ? "gemini-2.5-pro" : "gemini-flash-latest";

  const response = await ai.models.generateContentStream({
    model: modelName,
    contents: { parts },
    config: {
      systemInstruction: CHAT_SYSTEM_INSTRUCTION,
    }
  });

  return response;
};

export const generateChangeSummary = async (oldCode: string, newCode: string): Promise<string> => {
    if (oldCode === newCode) {
        return "No changes were made to the code.";
    }
    // A simple heuristic to detect the initial placeholder page.
    if (oldCode.includes('<h1 class="text-4xl font-bold text-gray-800 mb-4">Welcome to Your AI-Generated Website!</h1>')) {
        return "I've created a new website from scratch for you!";
    }

    const prompt = `You are a helpful AI assistant. Below is the old version and the new version of an HTML file. Briefly summarize the changes made between the old and new versions in a bulleted list (using '*' for bullets). Focus on user-visible changes (e.g., 'Added a navigation bar', 'Changed the hero section text', 'Styled the buttons to be blue'). Do not talk about code syntax. Keep it concise.

**Old Code:**
\`\`\`html
${oldCode}
\`\`\`

**New Code:**
\`\`\`html
${newCode}
\`\`\`
`;

    const response = await ai.models.generateContent({
        model: 'gemini-flash-latest',
        contents: prompt,
    });

    return response.text;
};