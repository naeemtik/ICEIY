import { initializeApp } from "firebase/app";
import { 
  getAuth, 
  createUserWithEmailAndPassword, 
  signInWithEmailAndPassword, 
  signOut, 
  onAuthStateChanged
} from "firebase/auth";
import { 
    getFirestore, 
    collection, 
    doc, 
    addDoc, 
    getDoc, 
    getDocs, 
    setDoc, 
    updateDoc, 
    query, 
    where, 
    serverTimestamp, 
    orderBy, 
    writeBatch 
} from "firebase/firestore";
import type { User } from 'firebase/auth';
import { Project, Message, Version } from '../types';

const firebaseConfig = {
  apiKey: "AIzaSyC82F4fMO5MGV44CGxCpe0UB9-4FsSELLU",
  authDomain: "cashpkr12.firebaseapp.com",
  projectId: "cashpkr12",
  storageBucket: "cashpkr12.firebasestorage.app",
  messagingSenderId: "126570347946",
  appId: "1:126570347946:web:4451b9cc1c534ab4d5bfd3",
  measurementId: "G-E1LQ84DCB8"
};

const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const db = getFirestore(app);

const projectsCollection = collection(db, 'projects');
const projectContentCollection = collection(db, 'project_content');

const signUpWithEmail = (email, password) => {
    return createUserWithEmailAndPassword(auth, email, password);
};

const signInWithEmail = (email, password) => {
    return signInWithEmailAndPassword(auth, email, password);
};

const signOutUser = () => {
    return signOut(auth);
};

// Firestore Project Functions
export const getProjectsForUser = async (uid: string): Promise<Project[]> => {
    // This query no longer uses a server-side sort to avoid requiring a composite index.
    // Sorting is now handled on the client-side.
    const q = query(projectsCollection, where("ownerUid", "==", uid));
    const querySnapshot = await getDocs(q);
    const projects: Project[] = [];
    querySnapshot.forEach((doc) => {
        const data = doc.data();
        projects.push({
            id: doc.id,
            name: data.name,
            // Convert Firestore Timestamp to milliseconds
            lastModified: data.lastModified?.toMillis() || Date.now(),
        });
    });

    // Sort projects on the client-side by last modified date, descending.
    projects.sort((a, b) => b.lastModified - a.lastModified);
    return projects;
};

export const createNewProjectInFirestore = async (uid: string, initialCode: string, initialMessages: Message[]): Promise<string> => {
    const newProjectRef = await addDoc(projectsCollection, {
        name: 'Untitled Project',
        ownerUid: uid,
        lastModified: serverTimestamp(),
    });
    
    await setDoc(doc(projectContentCollection, newProjectRef.id), {
        code: initialCode,
        messages: initialMessages,
        versions: [],
    });

    return newProjectRef.id;
};

export const getProjectMetadata = async (projectId: string, uid: string) => {
    const docRef = doc(db, 'projects', projectId);
    const docSnap = await getDoc(docRef);

    if (docSnap.exists() && docSnap.data().ownerUid === uid) {
        return { id: docSnap.id, ...docSnap.data() };
    } else {
        throw new Error("Project not found or access denied.");
    }
};

export const getProjectContent = async (projectId: string) => {
    const docRef = doc(db, 'project_content', projectId);
    const docSnap = await getDoc(docRef);

    if (docSnap.exists()) {
        return docSnap.data() as { code: string, messages: Message[], versions: Version[] };
    } else {
        return null;
    }
};

export const saveProjectDataToFirestore = async (projectId: string, data: { code: string; messages: Message[]; versions: Version[] }) => {
    const contentDocRef = doc(projectContentCollection, projectId);
    await setDoc(contentDocRef, data, { merge: true });

    const projectDocRef = doc(projectsCollection, projectId);
    await updateDoc(projectDocRef, {
        lastModified: serverTimestamp(),
    });
};

export const updateProjectNameInFirestore = async (projectId: string, name: string) => {
    const projectDocRef = doc(projectsCollection, projectId);
    await updateDoc(projectDocRef, {
        name: name,
        lastModified: serverTimestamp(),
    });
};

export const deleteProjectFromFirestore = async (projectId: string) => {
    const batch = writeBatch(db);

    const projectDocRef = doc(db, 'projects', projectId);
    batch.delete(projectDocRef);

    const contentDocRef = doc(db, 'project_content', projectId);
    batch.delete(contentDocRef);

    await batch.commit();
};


export { auth, signUpWithEmail, signInWithEmail, signOutUser, onAuthStateChanged };
export type { User };