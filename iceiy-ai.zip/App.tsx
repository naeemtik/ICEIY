import React, { useState, useEffect } from 'react';
import type { User } from 'firebase/auth';
import { auth, onAuthStateChanged, signOutUser } from './services/firebaseService';
import Auth from './components/Auth';
import Dashboard from './components/Dashboard';
import Editor from './components/Editor';
import Icon from './components/Icon';

const App: React.FC = () => {
    const [user, setUser] = useState<User | null>(null);
    const [authLoading, setAuthLoading] = useState(true);
    const [route, setRoute] = useState(window.location.hash || '#/');
    
    useEffect(() => {
        const handleHashChange = () => setRoute(window.location.hash || '#/');
        window.addEventListener('hashchange', handleHashChange, false);
        return () => window.removeEventListener('hashchange', handleHashChange, false);
    }, []);

    useEffect(() => {
        const unsubscribe = onAuthStateChanged(auth, (currentUser) => {
            setUser(currentUser);
            setAuthLoading(false);
        });
        return () => unsubscribe();
    }, []);

    useEffect(() => {
        if (!authLoading) {
            if (user && (route === '#/' || route === '')) {
                window.location.hash = '#/dashboard';
            } else if (!user && route !== '#/') {
                // Allow staying on the root/auth page without redirect loops
                if (window.location.hash !== '' && window.location.hash !== '#/') {
                   window.location.hash = '#/';
                }
            }
        }
    }, [user, authLoading, route]);

    const handleSignOut = async () => {
        try {
            await signOutUser();
            // The onAuthStateChanged listener will handle the redirect
        } catch (error) {
            console.error("Error signing out: ", error);
        }
    };

    if (authLoading) {
        return (
            <div className="h-screen w-screen bg-gray-900 flex flex-col items-center justify-center gap-4 text-white">
                <Icon name="spinner" className="w-10 h-10" />
                <p className="text-lg text-gray-400">Authenticating...</p>
            </div>
        );
    }

    const renderContent = () => {
        if (!user) {
            return <Auth />;
        }

        if (route.startsWith('#/editor/')) {
            const projectId = route.split('/')[2];
            if (!projectId) {
                window.location.hash = '#/dashboard';
                return null;
            }
            return <Editor projectId={projectId} user={user} handleSignOut={handleSignOut} />;
        }

        // Default to dashboard for any other authenticated route
        return <Dashboard user={user} handleSignOut={handleSignOut} />;
    };
    
    return <div className="bg-gray-900 h-screen w-screen">{renderContent()}</div>;
};

export default App;