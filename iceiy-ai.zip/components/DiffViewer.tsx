import React, { useMemo } from 'react';

interface DiffViewerProps {
  oldCode: string;
  newCode: string;
}

type DiffLine = {
  type: 'common' | 'added' | 'removed';
  line: string;
};

const diffLines = (oldStr: string, newStr: string): DiffLine[] => {
    const oldLines = oldStr.split('\n');
    const newLines = newStr.split('\n');
    const oldLen = oldLines.length;
    const newLen = newLines.length;

    const lcs = Array(oldLen + 1).fill(null).map(() => Array(newLen + 1).fill(0));

    for (let i = oldLen - 1; i >= 0; i--) {
        for (let j = newLen - 1; j >= 0; j--) {
            if (oldLines[i] === newLines[j]) {
                lcs[i][j] = 1 + lcs[i + 1][j + 1];
            } else {
                lcs[i][j] = Math.max(lcs[i + 1][j], lcs[i][j + 1]);
            }
        }
    }

    let i = 0, j = 0;
    const result: DiffLine[] = [];
    while (i < oldLen || j < newLen) {
        if (i < oldLen && j < newLen && oldLines[i] === newLines[j]) {
            result.push({ type: 'common', line: oldLines[i] });
            i++;
            j++;
        } else if (j < newLen && (i >= oldLen || lcs[i][j + 1] >= lcs[i + 1][j])) {
            result.push({ type: 'added', line: newLines[j] });
            j++;
        } else if (i < oldLen && (j >= newLen || lcs[i][j + 1] < lcs[i + 1][j])) {
            result.push({ type: 'removed', line: oldLines[i] });
            i++;
        } else {
          // Should not happen if logic is correct, but as a safeguard
          i++;
          j++;
        }
    }
    return result;
};


const DiffViewer: React.FC<DiffViewerProps> = ({ oldCode, newCode }) => {
  const diffResult = useMemo(() => diffLines(oldCode, newCode), [oldCode, newCode]);

  return (
    <pre className="w-full h-full p-4 overflow-auto bg-[#1e1e1e] text-white font-mono text-sm leading-normal">
      <code>
        {diffResult.map((item, index) => {
          const style = {
            'added': 'bg-green-900/50',
            'removed': 'bg-red-900/50',
            'common': ''
          }[item.type];
          
          const prefix = {
            'added': '+',
            'removed': '-',
            'common': ' '
          }[item.type];

          return (
            <div key={index} className={`flex ${style}`}>
                <span className="w-6 text-center select-none opacity-50">{prefix}</span>
                <span className="flex-1">{item.line}</span>
            </div>
          );
        })}
      </code>
    </pre>
  );
};

export default DiffViewer;
