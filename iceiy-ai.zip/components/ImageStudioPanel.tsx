import React, { useState } from 'react';
import Icon from './Icon';

interface GeneratedImage {
  prompt: string;
  dataUri: string;
}

interface ImageStudioPanelProps {
  generatedImages: GeneratedImage[];
  onGenerateImage: (prompt: string) => Promise<void>;
  isGenerating: boolean;
  onInsertCode: (codeToInsert: string) => void;
}

const ImageStudioPanel: React.FC<ImageStudioPanelProps> = ({ generatedImages, onGenerateImage, isGenerating, onInsertCode }) => {
  const [prompt, setPrompt] = useState('');
  const [copiedUrl, setCopiedUrl] = useState<string | null>(null);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!prompt.trim() || isGenerating) return;
    onGenerateImage(prompt);
    setPrompt('');
  };
  
  const handleCopyUrl = (url: string) => {
    navigator.clipboard.writeText(url);
    setCopiedUrl(url);
    setTimeout(() => setCopiedUrl(null), 2000);
  };

  const handleInsertCode = (image: GeneratedImage) => {
    const code = `<img src="${image.dataUri}" alt="${image.prompt.replace(/"/g, "'")}" class="w-full h-auto rounded-lg my-4" />`;
    onInsertCode(code);
  };

  return (
    <div className="bg-gray-800 rounded-lg flex flex-col h-full">
      <div className="p-4 border-b border-gray-700 flex items-center space-x-2">
        <Icon name="image" className="w-5 h-5 text-gray-400" />
        <h2 className="text-lg font-semibold text-gray-200">Image Studio</h2>
      </div>

      <div className="p-4 border-b border-gray-700">
        <form onSubmit={handleSubmit} className="flex gap-2">
          <input
            type="text"
            value={prompt}
            onChange={(e) => setPrompt(e.target.value)}
            placeholder="Describe an image to generate..."
            className="flex-1 bg-gray-700 border border-gray-600 rounded-md px-4 py-2 text-sm text-gray-200 focus:outline-none focus:ring-2 focus:ring-indigo-500 disabled:opacity-50"
            disabled={isGenerating}
            required
          />
          <button
            type="submit"
            className="bg-indigo-600 hover:bg-indigo-700 disabled:bg-indigo-800 disabled:cursor-not-allowed text-white font-semibold py-2 px-4 rounded-md flex items-center justify-center gap-2 transition-colors"
            disabled={isGenerating || !prompt}
          >
            {isGenerating ? <Icon name="spinner" className="w-5 h-5" /> : 'Generate'}
          </button>
        </form>
      </div>

      <div className="flex-1 p-4 overflow-y-auto">
        {generatedImages.length === 0 && !isGenerating && (
          <div className="text-center text-gray-500 mt-8 flex flex-col items-center h-full justify-center">
            <Icon name="image" className="w-12 h-12 mx-auto mb-2" />
            <p>Your generated images will appear here.</p>
          </div>
        )}
         {generatedImages.length === 0 && isGenerating && (
            <div className="text-center text-gray-500 mt-8 flex flex-col items-center h-full justify-center">
                <Icon name="spinner" className="w-12 h-12 mx-auto mb-2" />
                <p>Generating your image...</p>
            </div>
         )}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {generatedImages.map((image, index) => (
                <div key={index} className="bg-gray-900 rounded-lg overflow-hidden flex flex-col">
                    <img src={image.dataUri} alt={image.prompt} className="w-full h-40 object-cover" />
                    <div className="p-3 flex flex-col flex-grow">
                        <p className="text-xs text-gray-400 truncate mb-2 flex-grow" title={image.prompt}>{image.prompt}</p>
                        <div className="flex gap-2 mt-auto">
                            <button onClick={() => handleCopyUrl(image.dataUri)} className="text-xs flex-1 bg-gray-700 hover:bg-gray-600 text-white font-semibold py-1 px-2 rounded-md flex items-center justify-center gap-1.5 transition-colors">
                                <Icon name="copy" className="w-3 h-3"/>
                                {copiedUrl === image.dataUri ? 'Copied!' : 'Copy URL'}
                            </button>
                            <button onClick={() => handleInsertCode(image)} className="text-xs flex-1 bg-indigo-600 hover:bg-indigo-700 text-white font-semibold py-1 px-2 rounded-md flex items-center justify-center gap-1.5 transition-colors">
                                <Icon name="code" className="w-3 h-3"/>
                                Insert
                            </button>
                        </div>
                    </div>
                </div>
            ))}
        </div>
      </div>
    </div>
  );
};

export default ImageStudioPanel;
