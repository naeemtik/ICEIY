
import React from 'react';
import Icon from './Icon';

interface PreviewPanelProps {
  code: string;
}

const PreviewPanel: React.FC<PreviewPanelProps> = ({ code }) => {
  return (
    <div className="bg-gray-800 rounded-lg flex flex-col h-full">
      <div className="p-4 border-b border-gray-700 flex items-center space-x-2">
        <Icon name="preview" className="w-5 h-5 text-gray-400" />
        <h2 className="text-lg font-semibold text-gray-200">Live Preview</h2>
      </div>
      <div className="flex-1 p-1 bg-white rounded-b-lg">
        <iframe
          srcDoc={code}
          title="Website Preview"
          className="w-full h-full border-0"
          sandbox="allow-scripts allow-same-origin"
        />
      </div>
    </div>
  );
};

export default PreviewPanel;
