
import React, { useRef, useEffect, useState } from 'react';
import ReactMarkdown from 'react-markdown';
import remarkGfm from 'remark-gfm';
import { Message } from '../types';
import Icon from './Icon';

interface ChatPanelProps {
  messages: Message[];
  prompt: string;
  setPrompt: (prompt: string) => void;
  handleSubmit: (e: React.FormEvent) => void;
  isLoading: boolean;
  isThinking: boolean;
  isThinkingMode: boolean;
  setIsThinkingMode: (isThinking: boolean) => void;
  image: { data: string; mimeType: string; } | null;
  setImage: (image: { data:string; mimeType: string; } | null) => void;
  video: { data: string; mimeType: string; } | null;
  setVideo: (video: { data: string; mimeType: string; } | null) => void;
  handleFileUpload: (e: React.ChangeEvent<HTMLInputElement>) => void;
  selectedElement: { selector: string; label: string } | null;
  setSelectedElement: (element: { selector: string; label: string } | null) => void;
}

const ChatPanel: React.FC<ChatPanelProps> = ({ messages, prompt, setPrompt, handleSubmit, isLoading, isThinking, isThinkingMode, setIsThinkingMode, image, setImage, video, setVideo, handleFileUpload, selectedElement, setSelectedElement }) => {
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [thinkingStep, setThinkingStep] = useState(0);

  const thinkingSteps = [
    "Thinking...",
    "Analyzing your request...",
    "Drafting the structure...",
    "Applying advanced styling...",
    "Generating complex logic...",
    "Finalizing the code..."
  ];

  useEffect(() => {
    let interval: number | undefined;
    if (isLoading && isThinking) {
        interval = window.setInterval(() => {
            setThinkingStep(prev => (prev + 1) % thinkingSteps.length);
        }, 1500);
    }
    return () => {
        if (interval) clearInterval(interval);
        setThinkingStep(0); // Reset on stop
    };
  }, [isLoading, isThinking]);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
    // @ts-ignore: Accessing Prism from window object
    if (window.Prism) {
      // @ts-ignore
      window.Prism.highlightAll();
    }
  }, [messages]);

  const triggerFileInput = () => {
    fileInputRef.current?.click();
  };

  return (
    <div className="bg-gray-800 rounded-lg flex flex-col h-full">
      <div className="p-4 border-b border-gray-700 flex items-center">
        <h2 className="text-lg font-semibold text-gray-200">AI Agent Chat</h2>
      </div>
      <div className="flex-1 p-4 overflow-y-auto space-y-4">
        {messages.map((msg, index) => {
            if (msg.role === 'system') {
                return (
                    <div key={index} className="flex justify-center">
                        <div className="text-xs text-gray-400 italic bg-gray-700 px-3 py-1 rounded-full">
                            {msg.content}
                        </div>
                    </div>
                )
            }
            return (
              <div key={index} className={`flex items-start gap-3 ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                {msg.role === 'model' && (
                  <div className={`p-2 rounded-full flex-shrink-0 ${msg.isError ? 'bg-red-500' : 'bg-indigo-500'}`}>
                    <Icon name={msg.isError ? 'bug' : 'bot'} className="w-5 h-5" />
                  </div>
                )}
                <div className={`max-w-xs md:max-w-md lg:max-w-lg rounded-lg ${
                    msg.isError 
                        ? 'bg-red-900 border border-red-700' 
                        : msg.role === 'user' 
                        ? 'bg-blue-600' 
                        : 'bg-gray-700'
                }`}>
                  <div className="px-4 py-2 text-sm text-white">
                    {msg.image && (
                      <img src={`data:${msg.image.mimeType};base64,${msg.image.data}`} alt="User upload" className="rounded-md mb-2 max-h-48" />
                    )}
                    {msg.video && (
                      <video src={`data:${msg.video.mimeType};base64,${msg.video.data}`} controls className="rounded-md mb-2 max-h-48 w-full" />
                    )}
                     {msg.role === 'model' && !msg.isError ? (
                        <ReactMarkdown
                          remarkPlugins={[remarkGfm]}
                          components={{
                            p: ({node, ...props}) => <p className="mb-2 last:mb-0" {...props} />,
                            h1: ({node, ...props}) => <h1 className="text-xl font-bold my-2" {...props} />,
                            h2: ({node, ...props}) => <h2 className="text-lg font-bold my-2" {...props} />,
                            h3: ({node, ...props}) => <h3 className="font-bold my-2" {...props} />,
                            ul: ({node, ...props}) => <ul className="list-disc list-inside space-y-1 my-2" {...props} />,
                            ol: ({node, ...props}) => <ol className="list-decimal list-inside space-y-1 my-2" {...props} />,
                            li: ({node, ...props}) => <li className="leading-relaxed" {...props} />,
                            code: ({node, inline, className, children, ...props}) => {
                                const match = /language-(\w+)/.exec(className || '');
                                return !inline ? (
                                    <pre className="bg-gray-900/50 rounded-md p-3 my-2 text-xs leading-normal font-mono overflow-x-auto"><code className={`language-${match ? match[1] : ''}`}>{String(children).replace(/\n$/, '')}</code></pre>
                                ) : (
                                    <code className="bg-gray-600 rounded-sm px-1 py-0.5 font-mono text-xs" {...props}>
                                    {children}
                                    </code>
                                );
                            },
                            a: ({node, ...props}) => <a className="text-indigo-400 hover:underline" target="_blank" rel="noopener noreferrer" {...props} />,
                            blockquote: ({node, ...props}) => <blockquote className="border-l-4 border-gray-500 pl-4 italic my-2" {...props} />,
                            table: ({node, ...props}) => <div className="overflow-x-auto my-2"><table className="table-auto w-full text-left" {...props} /></div>,
                            thead: ({node, ...props}) => <thead className="font-bold bg-gray-600/50" {...props} />,
                            tbody: ({node, ...props}) => <tbody className="divide-y divide-gray-600" {...props} />,
                            tr: ({node, ...props}) => <tr className="border-b border-gray-600 last:border-b-0" {...props} />,
                            th: ({node, ...props}) => <th className="p-2" {...props} />,
                            td: ({node, ...props}) => <td className="p-2" {...props} />,
                          }}
                        >{msg.content}</ReactMarkdown>
                    ) : (
                        <p className="whitespace-pre-wrap">{msg.content}</p>
                    )}
                  </div>
                  {msg.citations && msg.citations.length > 0 && (
                    <div className="px-4 pt-2 pb-3 border-t border-gray-600">
                      <h4 className="text-xs font-semibold text-gray-400 mb-2">Sources:</h4>
                      <ul className="space-y-1">
                        {msg.citations.filter(c => c.web).map((citation, idx) => (
                          <li key={idx}>
                            <a href={citation.web.uri} target="_blank" rel="noopener noreferrer" className="text-xs text-indigo-400 hover:underline flex items-center gap-1.5">
                              <Icon name="externalLink" className="w-3 h-3 flex-shrink-0" />
                              <span className="truncate" title={citation.web.title}>{citation.web.title || citation.web.uri}</span>
                            </a>
                          </li>
                        ))}
                      </ul>
                    </div>
                  )}
                </div>
                 {msg.role === 'user' && (
                    <div className="p-2 rounded-full flex-shrink-0 bg-blue-600">
                        <Icon name="user" className="w-5 h-5" />
                    </div>
                 )}
              </div>
            )
        })}
        {isLoading && (
          <div className="flex items-start gap-3">
            <div className="p-2 bg-indigo-500 rounded-full"><Icon name="bot" className="w-5 h-5" /></div>
            <div className="max-w-xs px-4 py-3 rounded-lg bg-gray-700 flex items-center space-x-2">
                {isThinking ? (
                  <>
                    <Icon name="thinking" className="w-5 h-5" />
                    <span className="text-sm text-gray-300">{thinkingSteps[thinkingStep]}</span>
                  </>
                ) : (
                  <>
                    <Icon name="spinner" className="w-5 h-5"/>
                    <span className="text-sm text-gray-300">Generating...</span>
                  </>
                )}
            </div>
          </div>
        )}
        <div ref={messagesEndRef} />
      </div>
      <div className="p-4 border-t border-gray-700">
        <form onSubmit={handleSubmit} className="flex flex-col">
            {selectedElement && (
              <div className="mb-2 p-2 bg-gray-700 rounded-md text-sm text-gray-300 flex justify-between items-center gap-2">
                  <div className="flex items-center gap-2 truncate">
                    <Icon name="pencil" className="w-4 h-4 text-indigo-400 flex-shrink-0" />
                    <span className="truncate">Editing: <strong className="font-mono text-indigo-400" title={selectedElement.selector}>{selectedElement.label}</strong></span>
                  </div>
                  <button
                    type="button"
                    onClick={() => setSelectedElement(null)}
                    className="p-1 text-gray-400 hover:text-white hover:bg-gray-600 rounded-full transition-colors flex-shrink-0"
                    aria-label="Clear selection"
                  >
                    <Icon name="x" className="w-4 h-4" />
                  </button>
              </div>
            )}
            {image && (
                <div className="mb-2 relative w-32">
                    <img src={`data:${image.mimeType};base64,${image.data}`} alt="Preview" className="rounded-md h-32 w-32 object-cover" />
                    <button
                        type="button"
                        onClick={() => setImage(null)}
                        className="absolute -top-2 -right-2 bg-gray-700 text-white rounded-full p-1 hover:bg-gray-600 transition-colors"
                        aria-label="Remove image"
                    >
                        <Icon name="x" className="w-4 h-4" />
                    </button>
                </div>
            )}
            {video && (
                <div className="mb-2 relative w-48">
                    <video src={`data:${video.mimeType};base64,${video.data}`} controls className="rounded-md h-32 w-full object-cover"></video>
                    <button
                        type="button"
                        onClick={() => setVideo(null)}
                        className="absolute -top-2 -right-2 bg-gray-700 text-white rounded-full p-1 hover:bg-gray-600 transition-colors"
                        aria-label="Remove video"
                    >
                        <Icon name="x" className="w-4 h-4" />
                    </button>
                </div>
            )}
            <div className="flex flex-wrap items-center gap-2">
                 <input
                    type="file"
                    ref={fileInputRef}
                    onChange={handleFileUpload}
                    className="hidden"
                    accept="image/png, image/jpeg, image/webp, video/mp4, video/webm"
                    disabled={isLoading}
                 />
                 <button
                    type="button"
                    onClick={triggerFileInput}
                    className="p-2 text-gray-400 hover:text-white hover:bg-gray-700 rounded-md transition-colors disabled:opacity-50"
                    disabled={isLoading}
                    title="Attach image or video"
                >
                    <Icon name="attachment" className="w-5 h-5" />
                </button>
                <button
                    type="button"
                    onClick={() => setIsThinkingMode(!isThinkingMode)}
                    className={`p-2 rounded-md transition-colors disabled:opacity-50 ${isThinkingMode ? 'bg-indigo-600 text-white' : 'text-gray-400 hover:text-white hover:bg-gray-700'}`}
                    disabled={isLoading}
                    title="Toggle Thinking Mode for complex requests"
                >
                    <Icon name="thinking" className="w-5 h-5" />
                </button>
                <input
                    type="text"
                    value={prompt}
                    onChange={(e) => setPrompt(e.target.value)}
                    placeholder={selectedElement ? "Describe changes for the selected element..." : "Describe the website you want..."}
                    className="flex-1 min-w-[150px] bg-gray-700 border border-gray-600 rounded-md px-4 py-2 text-sm text-gray-200 focus:outline-none focus:ring-2 focus:ring-indigo-500 disabled:opacity-50"
                    disabled={isLoading}
                    required={!image && !video}
                />
                <button
                    type="submit"
                    className="bg-indigo-600 hover:bg-indigo-700 disabled:bg-indigo-800 disabled:cursor-not-allowed text-white font-semibold py-2 px-4 rounded-md flex items-center transition-colors"
                    disabled={isLoading || (!prompt && !image && !video)}
                >
                    <Icon name="send" className="w-5 h-5" />
                </button>
            </div>
        </form>
      </div>
    </div>
  );
};

export default ChatPanel;