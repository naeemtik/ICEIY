import React from 'react';
import { DatabaseTable } from '../types';
import Icon from './Icon';

interface DatabasePanelProps {
  database: DatabaseTable[];
}

const DatabasePanel: React.FC<DatabasePanelProps> = ({ database }) => {
  return (
    <div className="w-full h-full bg-[#1e1e1e] rounded-b-lg overflow-auto p-4 text-gray-300">
      {database.length === 0 ? (
        <div className="flex flex-col items-center justify-center h-full text-gray-500">
          <Icon name="database" className="w-16 h-16 mb-4" />
          <h3 className="text-lg font-semibold">No Tables in Database</h3>
          <p>You can ask the AI agent to create tables for you.</p>
          <p className="text-sm mt-2">e.g., "Create a users table with id, name, and email columns."</p>
        </div>
      ) : (
        <div className="space-y-6">
          {database.map(table => (
            <div key={table.id} className="bg-gray-800/50 rounded-lg p-4 border border-gray-700">
              <h4 className="text-lg font-bold text-indigo-400 mb-3">{table.name}</h4>
              <table className="w-full text-sm text-left">
                <thead className="text-xs text-gray-400 uppercase bg-gray-700/50">
                  <tr>
                    <th className="px-4 py-2">Column Name</th>
                    <th className="px-4 py-2">Data Type</th>
                  </tr>
                </thead>
                <tbody>
                  {table.columns.map(column => (
                    <tr key={column.id} className="border-b border-gray-700 last:border-0">
                      <td className="px-4 py-2 font-mono">{column.name}</td>
                      <td className="px-4 py-2 font-mono text-cyan-400">{column.type}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default DatabasePanel;
