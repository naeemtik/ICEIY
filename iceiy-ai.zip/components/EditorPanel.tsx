import React, { useState, useEffect, useRef } from 'react';
import Icon from './Icon';
import { Version } from '../types';
import DiffViewer from './DiffViewer';


interface CodePreviewPanelProps {
  code: string;
  setCode: (code: string) => void;
  iframeRef: React.RefObject<HTMLIFrameElement>;
  iframeErrors: string[];
  setIframeErrors: (errors: string[]) => void;
  onUploadCode: (code: string) => void;
  onDownloadCode: () => void;
  isSelectionModeActive: boolean;
  onToggleSelectionMode: () => void;
  versions: Version[];
  onRevert: (code: string) => void;
}

const CodePreviewPanel: React.FC<CodePreviewPanelProps> = ({ code, setCode, iframeRef, iframeErrors, setIframeErrors, onUploadCode, onDownloadCode, isSelectionModeActive, onToggleSelectionMode, versions, onRevert }) => {
  const [activeView, setActiveView] = useState<'editor' | 'preview' | 'history'>('editor');
  const [selectedVersion, setSelectedVersion] = useState<Version | null>(null);
  const preRef = useRef<HTMLPreElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    // @ts-ignore: Accessing Prism from window object
    if (window.Prism && activeView === 'editor') {
      // @ts-ignore
      window.Prism.highlightAll();
    }
  }, [code, activeView]);

  useEffect(() => {
    if (activeView === 'history' && versions.length > 0 && !selectedVersion) {
        setSelectedVersion(versions[0]);
    }
    if (activeView !== 'history') {
        setSelectedVersion(null);
    }
  }, [activeView, versions, selectedVersion]);

  const handleScroll = (e: React.UIEvent<HTMLTextAreaElement>) => {
    if (preRef.current) {
      preRef.current.scrollTop = e.currentTarget.scrollTop;
      preRef.current.scrollLeft = e.currentTarget.scrollLeft;
    }
  };

  const linkFixScript = `
    <script>
      document.addEventListener('DOMContentLoaded', () => {
        document.querySelectorAll('a[href="#"]').forEach(anchor => {
          anchor.addEventListener('click', (event) => {
            event.preventDefault();
            console.log('Default link behavior prevented for a placeholder link.');
          });
        });
      });
    </script>
  `;

  const errorDetectorScript = `
    <script>
      (() => {
        const formatError = (e) => {
          if (!e) return 'An unknown error occurred.';
          if (typeof e === 'string') return e;
          if (e.reason) return \`Unhandled Promise Rejection: \${e.reason.message || e.reason}\`;
          return e.message || 'An unknown error occurred.';
        };

        window.addEventListener('error', (event) => {
          window.parent.postMessage({
            type: 'iframeError',
            message: formatError(event.error || event)
          }, '*');
        });

        window.addEventListener('unhandledrejection', (event) => {
          window.parent.postMessage({
            type: 'iframeError',
            message: formatError(event)
          }, '*');
        });
        
        const originalConsoleError = console.error;
        console.error = function(...args) {
          window.parent.postMessage({
            type: 'iframeError',
            message: 'Console error: ' + args.map(arg => typeof arg === 'object' ? JSON.stringify(arg) : arg).join(' ')
          }, '*');
          originalConsoleError.apply(console, args);
        };
      })();
    </script>
  `;

  const elementSelectorScript = `
    <script>
      (() => {
        let selectionModeEnabled = false;
        const HOVER_ATTRIBUTE = 'data-ai-agent-hover';
        const SELECTED_ATTRIBUTE = 'data-ai-agent-selected';

        function getUniqueSelector(el) {
          if (!el || !(el instanceof Element)) return '';
          let selectorParts = [];
          let current = el;
          while (current && current.nodeType === Node.ELEMENT_NODE) {
            let part = current.tagName.toLowerCase();
            if (current.id) {
              part += '#' + current.id;
              selectorParts.unshift(part);
              break; 
            } else {
              let sibling = current;
              let nth = 1;
              while (sibling = sibling.previousElementSibling) {
                if (sibling.tagName.toLowerCase() === part) nth++;
              }
              if (nth > 1) {
                part += \`:nth-of-type(\${nth})\`;
              }
            }
            selectorParts.unshift(part);
            current = current.parentElement;
          }
          return selectorParts.join(' > ');
        }

        function removeAllAttributes(attr) {
          document.querySelectorAll(\`[\${attr}]\`).forEach(el => el.removeAttribute(attr));
        }

        document.addEventListener('mousemove', (e) => {
          if (!selectionModeEnabled) return;
          removeAllAttributes(HOVER_ATTRIBUTE);
          const el = document.elementFromPoint(e.clientX, e.clientY);
          if (el && el !== document.documentElement) {
            el.setAttribute(HOVER_ATTRIBUTE, 'true');
          }
        });

        document.addEventListener('mouseout', (e) => {
          if (!selectionModeEnabled) return;
          removeAllAttributes(HOVER_ATTRIBUTE);
        });

        document.addEventListener('click', (e) => {
          if (!selectionModeEnabled) return;
          e.preventDefault();
          e.stopPropagation();

          removeAllAttributes(SELECTED_ATTRIBUTE);
          const el = document.elementFromPoint(e.clientX, e.clientY);
          if (el) {
            const selector = getUniqueSelector(el);
            const label = el.getAttribute('aria-label') || el.innerText.substring(0, 30).trim() || el.tagName.toLowerCase();
            el.setAttribute(SELECTED_ATTRIBUTE, 'true');
            window.parent.postMessage({ type: 'elementSelected', selector: selector, label: label }, '*');
          }
        }, true);

        window.addEventListener('message', (event) => {
          if (event.data?.type === 'toggleSelectionMode') {
            selectionModeEnabled = event.data.enable;
            document.body.style.cursor = selectionModeEnabled ? 'crosshair' : 'default';
            if (!selectionModeEnabled) {
              removeAllAttributes(HOVER_ATTRIBUTE);
              removeAllAttributes(SELECTED_ATTRIBUTE);
            }
          }
        });

        const style = document.createElement('style');
        style.textContent = \`
          [data-ai-agent-hover] {
            outline: 2px solid #3b82f6 !important;
            box-shadow: 0 0 10px rgba(59, 130, 246, 0.7) !important;
            transition: outline 0.1s ease-in-out;
          }
          [data-ai-agent-selected] {
            outline: 3px solid #10b981 !important;
            box-shadow: 0 0 15px rgba(16, 185, 129, 0.8) !important;
          }
        \`;
        document.head.appendChild(style);
      })();
    </script>
  `;


  const getEnhancedCode = (htmlContent: string) => {
    const scripts = errorDetectorScript + linkFixScript + elementSelectorScript;
    
    if (htmlContent.includes('</head>')) {
      return htmlContent.replace('</head>', `${scripts}</head>`);
    }
    if (htmlContent.includes('</body>')) {
      return htmlContent.replace('</body>', `${scripts}</body>`);
    }
    return `${htmlContent}${scripts}`;
  };
  
  const enhancedCode = getEnhancedCode(code);

  const handleOpenInNewTab = () => {
    try {
        const blob = new Blob([code], { type: 'text/html' });
        const url = URL.createObjectURL(blob);
        window.open(url, '_blank', 'noopener,noreferrer');
    } catch (e) {
        console.error("Error opening in new tab:", e);
    }
  };
  
  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (e) => {
        const text = e.target?.result;
        if (typeof text === 'string') {
          onUploadCode(text);
        }
      };
      reader.readAsText(file);
    }
    if (event.target) {
        event.target.value = '';
    }
  };

  const triggerFileUpload = () => {
    fileInputRef.current?.click();
  };
  
  const formatDate = (timestamp: number) => {
    return new Date(timestamp).toLocaleString(undefined, {
        dateStyle: 'medium',
        timeStyle: 'short'
    });
  }

  return (
    <div className="bg-gray-800 rounded-lg flex flex-col h-full">
      <div className="p-4 border-b border-gray-700 flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center gap-2">
           <Icon name={activeView === 'editor' ? 'code' : activeView === 'preview' ? 'preview' : 'history'} className="w-5 h-5 text-gray-400" />
           <h2 className="text-lg font-semibold text-gray-200">
             {activeView === 'editor' ? 'index.html' : activeView === 'preview' ? 'Live Preview' : 'Version History'}
           </h2>
        </div>
        <div className="flex items-center flex-wrap justify-end gap-2">
            <button
                onClick={onToggleSelectionMode}
                title="Select element to edit"
                className={`flex items-center space-x-2 px-3 py-1.5 rounded-lg text-sm transition-colors ${isSelectionModeActive ? 'bg-indigo-600 text-white' : 'bg-gray-900 text-gray-400 hover:bg-gray-700 hover:text-white'}`}
            >
                <Icon name="pencil" className="w-4 h-4"/>
                <span>Select Element</span>
            </button>
            <div className="flex items-center gap-1 bg-gray-900 p-1 rounded-lg">
                <button 
                    onClick={() => setActiveView('editor')} 
                    title="Show Editor" 
                    className={`flex items-center space-x-2 px-3 py-1 rounded-md text-sm transition-colors ${activeView === 'editor' ? 'bg-indigo-600 text-white' : 'text-gray-400 hover:bg-gray-700'}`}
                >
                    <Icon name="code" className="w-4 h-4"/>
                    <span>Editor</span>
                </button>
                <button 
                    onClick={() => setActiveView('preview')} 
                    title="Show Preview" 
                    className={`flex items-center space-x-2 px-3 py-1 rounded-md text-sm transition-colors ${activeView === 'preview' ? 'bg-indigo-600 text-white' : 'text-gray-400 hover:bg-gray-700'}`}
                >
                    <Icon name="preview" className="w-4 h-4"/>
                    <span>Preview</span>
                </button>
                <button
                    onClick={() => setActiveView('history')}
                    title="Show Version History"
                    className={`flex items-center space-x-2 px-3 py-1 rounded-md text-sm transition-colors ${activeView === 'history' ? 'bg-indigo-600 text-white' : 'text-gray-400 hover:bg-gray-700'}`}
                >
                    <Icon name="history" className="w-4 h-4" />
                    <span>History</span>
                </button>
            </div>
             <input
                type="file"
                ref={fileInputRef}
                onChange={handleFileUpload}
                className="hidden"
                accept=".html"
              />
             <button 
                onClick={triggerFileUpload}
                title="Upload HTML file" 
                className="p-2 rounded-lg text-gray-400 bg-gray-900 hover:bg-gray-700 hover:text-white transition-colors"
            >
                <Icon name="upload" className="w-5 h-5"/>
            </button>
             <button 
                onClick={onDownloadCode}
                title="Download Project (ZIP)" 
                className="p-2 rounded-lg text-gray-400 bg-gray-900 hover:bg-gray-700 hover:text-white transition-colors"
            >
                <Icon name="download" className="w-5 h-5"/>
            </button>
             <button 
                onClick={handleOpenInNewTab} 
                title="Open Preview in New Tab" 
                className="p-2 rounded-lg text-gray-400 bg-gray-900 hover:bg-gray-700 hover:text-white transition-colors"
            >
                <Icon name="externalLink" className="w-5 h-5"/>
            </button>
        </div>
      </div>
      <div className="flex-1 p-1">
        {activeView === 'history' ? (
             <div className="flex w-full h-full bg-[#1e1e1e] rounded-b-lg overflow-hidden">
                <aside className="w-1/3 max-w-sm h-full bg-gray-900/50 flex flex-col">
                    <h3 className="flex-shrink-0 p-4 text-sm font-semibold text-gray-300 border-b border-gray-700">Version History</h3>
                    <ul className="flex-1 overflow-y-auto">
                        {versions.map(v => (
                            <li key={v.id}>
                                <button
                                    onClick={() => setSelectedVersion(v)}
                                    className={`w-full text-left p-4 border-l-4 transition-colors ${selectedVersion?.id === v.id ? 'bg-indigo-900/50 border-indigo-500' : 'border-transparent hover:bg-gray-800/50'}`}
                                >
                                    <p className="text-sm font-semibold text-gray-200">{formatDate(v.timestamp)}</p>
                                    <ul className="mt-2 text-xs text-gray-400 list-none m-0 p-0 space-y-1">
                                      {v.summary.split('\n').map((line, i) => (
                                        <li key={i} className="truncate">{line.replace(/^\s*\*\s*/, '• ')}</li>
                                      ))}
                                    </ul>
                                </button>
                            </li>
                        ))}
                         {versions.length === 0 && <p className="p-4 text-sm text-gray-500">No versions saved yet.</p>}
                    </ul>
                </aside>
                <main className="flex-1 h-full flex flex-col">
                    {selectedVersion ? (
                        <>
                            <header className="flex-shrink-0 p-3 bg-gray-900/70 border-b border-gray-700 flex items-center justify-between">
                                <div>
                                    <p className="text-xs text-gray-400">Comparing with current code</p>
                                    <p className="text-sm font-semibold text-white">Version from {formatDate(selectedVersion.timestamp)}</p>
                                </div>
                                <button
                                    onClick={() => onRevert(selectedVersion.code)}
                                    className="bg-indigo-600 hover:bg-indigo-700 text-white font-semibold py-1.5 px-3 rounded-md text-sm transition-colors"
                                >
                                    Revert to this version
                                </button>
                            </header>
                            <div className="flex-1 overflow-hidden">
                                <DiffViewer oldCode={selectedVersion.code} newCode={code} />
                            </div>
                        </>
                    ) : (
                        <div className="flex items-center justify-center h-full">
                            <p className="text-gray-500">Select a version to see changes.</p>
                        </div>
                    )}
                </main>
            </div>
        ) : activeView === 'editor' ? (
          <div className="relative w-full h-full font-mono text-sm bg-[#1e1e1e] rounded-b-lg">
            <textarea
              value={code}
              onChange={(e) => setCode(e.target.value)}
              onScroll={handleScroll}
              className="absolute top-0 left-0 z-10 w-full h-full p-4 overflow-auto bg-transparent border-none outline-none resize-none text-transparent caret-[#d4d4d4] selection:bg-blue-800 whitespace-pre-wrap break-words [tab-size:4] leading-normal"
              spellCheck="false"
            />
            <pre
              ref={preRef}
              className="absolute top-0 left-0 z-0 w-full h-full p-4 overflow-auto pointer-events-none whitespace-pre-wrap break-words [tab-size:4] leading-normal"
              aria-hidden="true"
            >
              <code className="language-html">
                {code + '\n'}
              </code>
            </pre>
          </div>
        ) : (
          <div className="relative w-full h-full bg-white rounded-b-lg">
            <iframe
              ref={iframeRef}
              srcDoc={enhancedCode}
              title="Website Preview"
              className={`w-full h-full border-0 ${isSelectionModeActive ? 'cursor-crosshair' : ''}`}
              sandbox="allow-scripts allow-same-origin"
            />
          </div>
        )}
      </div>
    </div>
  );
};

export default CodePreviewPanel;