
import React, { useState, useEffect } from 'react';
import type { User } from 'firebase/auth';
import { 
    getProjectsForUser, 
    createNewProjectInFirestore,
    deleteProjectFromFirestore
} from '../services/firebaseService';
import { Project, Message } from '../types';
import Icon from './Icon';

interface DashboardProps {
    user: User;
    handleSignOut: () => void;
}

const INITIAL_CODE = `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>New Project</title>
  <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100 flex items-center justify-center h-screen">
  <div class="text-center p-8">
    <h1 class="text-4xl font-bold text-gray-800 mb-4">Welcome to Your New Website!</h1>
    <p class="text-lg text-gray-600">Start by describing the website you want to build in the chat panel.</p>
  </div>
</body>
</html>`;

const ONE_MONTH_MS = 30 * 24 * 60 * 60 * 1000;
const SEVEN_DAYS_MS = 7 * 24 * 60 * 60 * 1000;

const useCountdown = (targetTimestamp: number) => {
    const [remaining, setRemaining] = useState(targetTimestamp - Date.now());

    useEffect(() => {
        const interval = setInterval(() => {
            const newRemaining = targetTimestamp - Date.now();
            setRemaining(newRemaining > 0 ? newRemaining : 0);
        }, 1000);

        return () => clearInterval(interval);
    }, [targetTimestamp]);
    
    if (remaining <= 0) {
        return { formatted: "0d 00:00:00", isFinished: true };
    }

    const days = Math.floor(remaining / (1000 * 60 * 60 * 24));
    const hours = Math.floor((remaining % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
    const minutes = Math.floor((remaining % (1000 * 60 * 60)) / (1000 * 60));
    const seconds = Math.floor((remaining % (1000 * 60)) / 1000);

    let formatted = '';
    if (days > 0) {
        formatted += `${days}d `;
    }
    formatted += `${String(hours).padStart(2, '0')}:${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}`;

    return { formatted, isFinished: false };
};


const ProjectCard: React.FC<{ project: Project; onOpen: (id: string) => void; }> = ({ project, onOpen }) => {
    const expiryTimestamp = project.lastModified + ONE_MONTH_MS;
    const timeRemaining = expiryTimestamp - Date.now();
    const isNearingDeletion = timeRemaining > 0 && timeRemaining <= SEVEN_DAYS_MS;
    
    const { formatted: timerText, isFinished } = useCountdown(expiryTimestamp);
    const timerVisible = !isFinished;
    
    const formatDate = (timestamp: number) => {
        return new Date(timestamp).toLocaleDateString(undefined, {
            year: 'numeric',
            month: 'short',
            day: 'numeric',
            hour: '2-digit',
            minute: '2-digit'
        });
    };

    return (
        <div
            onClick={() => onOpen(project.id)}
            className={`group relative bg-gray-800 rounded-lg overflow-hidden transition-all duration-300 hover:scale-105 shadow-lg hover:shadow-indigo-500/20 min-h-[200px] cursor-pointer border-2 ${isNearingDeletion ? 'border-red-500/50' : 'border-transparent'}`}
        >
            {timerVisible && (
                <div className={`absolute top-0 left-0 w-full p-2 ${isNearingDeletion ? 'bg-red-800/80' : 'bg-gray-900/80'} backdrop-blur-sm text-center z-10`}>
                    <p className={`text-xs font-semibold flex items-center justify-center gap-1.5 ${isNearingDeletion ? 'text-white' : 'text-green-400'}`}>
                        {isNearingDeletion && <Icon name="warning" className="w-4 h-4" />}
                        {isNearingDeletion ? 'Deletes in:' : 'Expires in:'} {timerText}
                    </p>
                </div>
            )}
            <div className={`flex flex-col h-full ${timerVisible ? 'pt-8' : ''}`}>
                <div className="flex-1 flex flex-col items-center justify-center p-6 text-center">
                    <Icon name="code" className="w-12 h-12 text-gray-500 mb-3 transition-transform duration-300 group-hover:scale-110" />
                    <h3 className="text-gray-100 truncate w-full" title={project.name}>{project.name}</h3>
                </div>
                <div className="p-3 bg-gray-900/50 border-t border-gray-700">
                    <p className="text-xs text-gray-400">Last updated:</p>
                    <p className="text-xs text-gray-300">{formatDate(project.lastModified)}</p>
                </div>
            </div>
            <div className="absolute inset-0 bg-gray-900 bg-opacity-70 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-300 pointer-events-none">
                <span className="flex items-center gap-2 text-lg font-semibold bg-indigo-600 text-white py-2 px-4 rounded-lg shadow-lg">
                    <Icon name="pencil" className="w-5 h-5" />
                    <span>Open Project</span>
                </span>
            </div>
        </div>
    );
};


const Dashboard: React.FC<DashboardProps> = ({ user, handleSignOut }) => {
    const [projects, setProjects] = useState<Project[]>([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState<string | null>(null);

    useEffect(() => {
        const fetchProjects = async () => {
            try {
                const userProjects = await getProjectsForUser(user.uid);
                
                const now = Date.now();
                
                const projectsToDelete = userProjects.filter(p => (now - p.lastModified) > ONE_MONTH_MS);
                const projectsToKeep = userProjects.filter(p => (now - p.lastModified) <= ONE_MONTH_MS);

                if (projectsToDelete.length > 0) {
                    console.log(`Auto-deleting ${projectsToDelete.length} inactive project(s).`);
                    await Promise.all(projectsToDelete.map(p => deleteProjectFromFirestore(p.id)));
                }

                setProjects(projectsToKeep);

            } catch (err: any) {
                console.error("Failed to load projects:", err);
                if (err.message && err.message.includes("Missing or insufficient permissions")) {
                    setError("Failed to load projects due to a database permissions error. Please check your Firestore security rules to ensure authenticated users can read their own projects.");
                } else {
                    setError("An unexpected error occurred while loading your projects.");
                }
            } finally {
                setLoading(false);
            }
        };
        fetchProjects();
    }, [user.uid]);

    const createNewProject = async () => {
        try {
            const initialMessages: Message[] = [
                {
                    role: 'model',
                    content: 'Hello! What kind of website would you like to create today? You can also upload an image or video for inspiration.'
                }
            ];
            const newProjectId = await createNewProjectInFirestore(user.uid, INITIAL_CODE, initialMessages);
            window.location.hash = `#/editor/${newProjectId}`;
        } catch (error) {
            console.error("Failed to create new project:", error);
            alert("Could not create a new project. Please try again.");
        }
    };

    const openProject = (projectId: string) => {
        window.location.hash = `#/editor/${projectId}`;
    };

    return (
        <div className="flex flex-col h-screen bg-gray-900 text-white">
            {/* Header */}
            <header className="flex-shrink-0 bg-gray-800/50 backdrop-blur-sm border-b border-gray-700">
                <div className="container mx-auto px-4 sm:px-6 lg:px-8">
                    <div className="flex items-center justify-between h-16">
                        <div className="flex items-center gap-3">
                            <div className="p-2 bg-indigo-500 rounded-lg">
                                <Icon name="bot" className="w-6 h-6" />
                            </div>
                            <h1 className="text-xl sm:text-2xl font-bold">Iceiy AI Dashboard</h1>
                        </div>
                        <div className="flex items-center gap-2 sm:gap-4">
                            <div className="hidden md:flex items-center gap-2 text-sm text-gray-300">
                                <Icon name="user" className="w-4 h-4" />
                                <span className="truncate max-w-[150px]" title={user.email || 'User'}>
                                    {user.email}
                                </span>
                            </div>
                            <button
                                onClick={handleSignOut}
                                title="Sign Out"
                                className="p-2 rounded-md bg-gray-700 text-gray-300 hover:bg-red-600 hover:text-white transition-colors"
                            >
                                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                                    <path strokeLinecap="round" strokeLinejoin="round" d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1" />
                                </svg>
                            </button>
                        </div>
                    </div>
                </div>
            </header>

            {/* Main Content */}
            <main className="flex-1 overflow-y-auto">
                <div className="container mx-auto p-4 sm:p-6 lg:p-8">
                    <h2 className="text-2xl font-bold mb-6 text-gray-200">My Projects</h2>

                    {error && (
                        <div className="bg-red-900 border border-red-700 text-red-200 px-4 py-3 rounded-lg mb-6 flex items-start" role="alert">
                            <Icon name="warning" className="w-5 h-5 mr-3 mt-1 flex-shrink-0"/>
                            <div>
                                <p className="font-bold">Failed to load projects: Missing or insufficient permissions.</p>
                                <p className="text-sm mt-1">Please check your Firestore security rules to ensure authenticated users are allowed to read their projects.</p>
                            </div>
                        </div>
                    )}
                    
                    {loading ? (
                        <div className="flex justify-center items-center h-64">
                            {Icon ? (
                                <Icon name="spinner" className="w-8 h-8 animate-spin text-indigo-400" />
                            ) : (
                                <div className="animate-spin rounded-full h-8 w-8 border-t-2 border-indigo-500 border-opacity-75"></div>
                            )}
                        </div>
                    ) : (
                        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-6">
                            {/* Create New Project */}
                            <button
                                onClick={createNewProject}
                                className="group flex flex-col items-center justify-center bg-gray-800 hover:bg-indigo-500/10 border-2 border-dashed border-gray-700 hover:border-indigo-500 rounded-lg p-6 transition-all duration-300 min-h-[200px]"
                            >
                                <div className="bg-gray-700 group-hover:bg-indigo-500 p-4 rounded-full transition-colors">
                                    <Icon name="plus" className="w-8 h-8 text-gray-400 group-hover:text-white" />
                                </div>
                                <span className="mt-4 font-semibold text-lg text-gray-300 group-hover:text-indigo-400">Create New Project</span>
                            </button>

                            {/* Project Cards */}
                            {projects.map(project => (
                                <ProjectCard key={project.id} project={project} onOpen={openProject} />
                            ))}
                        </div>
                    )}

                    {/* Empty State */}
                    {!loading && projects.length === 0 && !error && (
                        <div className="text-center py-16 text-gray-500">
                            <p>You don't have any projects yet.</p>
                            <p>Click "Create New Project" to get started!</p>
                        </div>
                    )}
                </div>
            </main>
        </div>
    );
};

export default Dashboard;