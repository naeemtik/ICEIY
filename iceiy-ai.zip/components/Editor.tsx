
import React, { useState, useRef, useEffect, useCallback } from 'react';
import type { User } from 'firebase/auth';
import ChatPanel from './ChatPanel';
import CodePreviewPanel from './EditorPanel';
import { Message, GroundingChunk, Version, Project } from '../types';
import { generateWebsiteCodeStream, getChatResponseStream, generateChangeSummary } from '../services/geminiService';
import { getProjectMetadata, getProjectContent, saveProjectDataToFirestore, updateProjectNameInFirestore } from '../services/firebaseService';
import Icon from './Icon';

declare const JSZip: any;

interface EditorProps {
    projectId: string;
    user: User;
    handleSignOut: () => void;
}

const useDebounce = <T,>(value: T, delay: number): T => {
    const [debouncedValue, setDebouncedValue] = useState<T>(value);
    useEffect(() => {
        const handler = setTimeout(() => {
            setDebouncedValue(value);
        }, delay);
        return () => {
            clearTimeout(handler);
        };
    }, [value, delay]);
    return debouncedValue;
};


const Editor: React.FC<EditorProps> = ({ projectId, user, handleSignOut }) => {
  const [messages, setMessages] = useState<Message[]>([]);
  const [prompt, setPrompt] = useState('');
  const [code, setCode] = useState<string>('');
  const [versions, setVersions] = useState<Version[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [iframeErrors, setIframeErrors] = useState<string[]>([]);
  const [image, setImage] = useState<{ data: string; mimeType: string; } | null>(null);
  const [video, setVideo] = useState<{ data: string; mimeType: string; } | null>(null);
  const [isThinkingMode, setIsThinkingMode] = useState(false);
  const [wasThinking, setWasThinking] = useState(false);
  const iframeRef = useRef<HTMLIFrameElement>(null);
  const [isSelectionModeActive, setIsSelectionModeActive] = useState(false);
  const [selectedElement, setSelectedElement] = useState<{ selector: string; label: string } | null>(null);

  const [projectName, setProjectName] = useState('Loading...');
  const [isDataLoaded, setIsDataLoaded] = useState(false);
  const [isEditingName, setIsEditingName] = useState(false);
  const nameInputRef = useRef<HTMLInputElement>(null);
  const [showInactivityWarning, setShowInactivityWarning] = useState(false);

  const projectDataToSave = useRef({ code, messages, versions });

  useEffect(() => {
    projectDataToSave.current = { code, messages, versions };
  }, [code, messages, versions]);
  
  const [saveTrigger, setSaveTrigger] = useState(0);
  const debouncedSaveTrigger = useDebounce(saveTrigger, 2000);

  useEffect(() => {
    if (isDataLoaded) {
      setSaveTrigger(Date.now());
    }
  }, [code, messages, versions, isDataLoaded]);

  useEffect(() => {
    if (!isDataLoaded || debouncedSaveTrigger === 0) return;

    const saveData = async () => {
      try {
        await saveProjectDataToFirestore(projectId, projectDataToSave.current);
        if (error === "Failed to save changes. Please check your connection.") {
            setError(null);
        }
      } catch (err) {
        console.error("Failed to save project data:", err);
        setError("Failed to save changes. Please check your connection.");
      }
    };
    saveData();
  }, [debouncedSaveTrigger, projectId, isDataLoaded, error]);


  useEffect(() => {
    const loadProjectData = async () => {
        setIsDataLoaded(false);
        setError(null);
        try {
            const projectMeta = await getProjectMetadata(projectId, user.uid);
            setProjectName(projectMeta.name);

            const lastModifiedTime = projectMeta.lastModified?.toMillis() || Date.now();
            // Show warning if project has been inactive for over 23 days (entering the last 7 days of its 30-day lifecycle)
            const INACTIVITY_THRESHOLD_MS = 23 * 24 * 60 * 60 * 1000;
            if ((Date.now() - lastModifiedTime) > INACTIVITY_THRESHOLD_MS) {
                setShowInactivityWarning(true);
            }

            const projectContent = await getProjectContent(projectId);
            if (projectContent) {
                setCode(projectContent.code || '');
                setMessages(projectContent.messages || [{ role: 'model', content: 'Hello! How can I help you build your website?' }]);
                setVersions(projectContent.versions || []);
            }
        } catch (e) {
            console.error("Error loading project data:", e);
            const errorMessage = e instanceof Error ? e.message : "An unknown error occurred.";
            if (errorMessage.includes('access denied')) {
                window.location.hash = '#/dashboard';
                return;
            }
            setError(`Failed to load project data: ${errorMessage}`);
            setProjectName('Error');
        } finally {
            setIsDataLoaded(true);
        }
    };

    loadProjectData();
  }, [projectId, user.uid]);
  
  useEffect(() => {
    if (isEditingName && nameInputRef.current) {
        nameInputRef.current.focus();
        nameInputRef.current.select();
    }
  }, [isEditingName]);

  const handleProjectNameChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setProjectName(e.target.value);
  };

  const saveProjectName = async () => {
    const trimmedName = projectName.trim() || "Untitled Project";
    setProjectName(trimmedName);
    setIsEditingName(false);
    try {
        await updateProjectNameInFirestore(projectId, trimmedName);
    } catch(err) {
        console.error("Failed to update project name:", err);
        setError("Could not update project name.");
    }
  };

  const handleNameInputBlur = () => {
    saveProjectName();
  };

  const handleNameInputKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter') {
        saveProjectName();
    } else if (e.key === 'Escape') {
        setIsEditingName(false);
        // Re-fetch original name to discard changes
        getProjectMetadata(projectId, user.uid).then(meta => setProjectName(meta.name)).catch(() => {});
    }
  };

  const handleAutoFixError = async (errors: string[]) => {
      setIsLoading(true);
      setWasThinking(true);
      setError(null);
      const systemMessage: Message = { role: 'system', content: 'An error was detected. Automatically fix it.' };
      try {
          const oldCode = code;
          const stream = await generateWebsiteCodeStream([systemMessage], code, true, errors, null);
          let accumulatedCode = "", firstChunk = true;
          const citations = new Map<string, GroundingChunk>();
          for await (const chunk of stream) {
              if (firstChunk) { setCode(''); firstChunk = false; }
              accumulatedCode += chunk.text;
              setCode(accumulatedCode.replace(/^```html\n|```$/g, '').trim());
              chunk.candidates?.[0]?.groundingMetadata?.groundingChunks?.forEach(c => c.web && citations.set(c.web.uri, c));
          }
          const finalCode = accumulatedCode.replace(/^```html\n|```$/g, '').trim();
          setCode(finalCode);
          let summary = "I've attempted to fix the error in the code.";
          if (finalCode && oldCode !== finalCode) {
              try {
                  summary = await generateChangeSummary(oldCode, finalCode);
                   const newVersion: Version = {
                        id: Date.now().toString(),
                        timestamp: Date.now(),
                        code: finalCode,
                        summary: summary,
                    };
                    setVersions(prev => [newVersion, ...prev].slice(0, 20));
              } catch(e) { console.error("Failed summary:", e); summary += "\nPlease review changes."; }
          }
          setMessages(prev => [...prev, { role: 'model', content: `I've attempted to fix the error in the code.\n\n**Changes:**\n${summary}`, citations: Array.from(citations.values()) }]);
          setIframeErrors([]);
      } catch (err) {
          const msg = err instanceof Error ? err.message : 'Error during fix.';
          setError(msg);
          setMessages(prev => [...prev, { role: 'model', content: `Sorry, error fixing site: ${msg}`, isError: true }]);
      } finally {
          setIsLoading(false);
          setWasThinking(false);
      }
  };

  useEffect(() => {
    const handleMessage = (event: MessageEvent) => {
      if (event.source !== iframeRef.current?.contentWindow) return;

      if (event.data?.type === 'iframeError') {
        const errorMessage = event.data.message || 'Unknown error in preview.';
        if (isLoading || iframeErrors.includes(errorMessage)) return;
        const newErrors = [...iframeErrors, errorMessage];
        setIframeErrors(newErrors);
        setMessages(prev => [...prev, { role: 'model', content: `JS error detected:\n\`\`\`\n${errorMessage}\n\`\`\`\nI will try to fix it.`, isError: true }]);
        handleAutoFixError(newErrors);
      } else if (event.data?.type === 'elementSelected') {
        setSelectedElement({ selector: event.data.selector, label: event.data.label });
        setIsSelectionModeActive(false);
        setMessages(prev => [...prev, { role: 'system', content: `Element "${event.data.label}" selected. Describe your changes.`}]);
      }
    };
    window.addEventListener('message', handleMessage);
    return () => window.removeEventListener('message', handleMessage);
  }, [isLoading, iframeErrors, code]); // Added 'code' to re-attach listener with fresh state
  
  const handleToggleSelectionMode = () => {
    const nextState = !isSelectionModeActive;
    setIsSelectionModeActive(nextState);
    setSelectedElement(null); 
    iframeRef.current?.contentWindow?.postMessage({ type: 'toggleSelectionMode', enable: nextState }, '*');
  };

  const fileToBase64 = (file: File): Promise<string> => new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = () => resolve((reader.result as string).split(',')[1]);
    reader.onerror = (error) => reject(error);
  });

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    e.target.value = '';
    try {
        const base64Data = await fileToBase64(file);
        if (file.type.startsWith('image/')) { setVideo(null); setImage({ data: base64Data, mimeType: file.type }); }
        else if (file.type.startsWith('video/')) { setImage(null); setVideo({ data: base64Data, mimeType: file.type }); }
        else { setError("Unsupported file type. Please upload an image or video."); }
    } catch (err) {
        setError(err instanceof Error ? err.message : 'Could not process file.');
    }
  };
  
  const handleDownloadCode = () => {
      const zip = new JSZip();
      zip.file("index.html", code);
      zip.generateAsync({ type: "blob" }).then((content: Blob) => {
        const url = URL.createObjectURL(content);
        const a = document.createElement('a');
        a.href = url;
        a.download = `${projectName.replace(/ /g, '_') || 'project'}.zip`;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
      });
  };

  const handleUploadCode = (uploadedCode: string) => {
    setCode(uploadedCode);
    setMessages(prev => [...prev, {role: 'model', content: 'Code loaded from your HTML file.'}]);
  };

  const executePrompt = async (promptToExecute: string, media: { image: any, video: any } | null) => {
    if(isLoading) return;
    const messageContent: Message = { role: 'user', content: promptToExecute, ...(media?.image && { image: media.image }), ...(media?.video && { video: media.video }) };
    const currentMessages = [...messages, messageContent];
    setMessages(currentMessages);
    setPrompt(''); setImage(null); setVideo(null);
    setWasThinking(isThinkingMode || !!selectedElement);
    setIsLoading(true); setError(null);
    
    try {
      const isCodeRequest = media?.image || media?.video || iframeErrors.length > 0 || !!selectedElement || ['create', 'build', 'generate', 'change', 'update', 'modify', 'add', 'make', 'clone', 'design', 'style', 'code', 'html', 'page', 'site', 'website', 'game', 'color', 'font', 'button', 'text', 'heading', 'layout', 'div', 'section', 'header', 'footer', 'fix', 'error', 'debug'].some(keyword => promptToExecute.toLowerCase().includes(keyword));
      const citations = new Map<string, GroundingChunk>();

      if (isCodeRequest) {
        if(iframeErrors.length > 0) setWasThinking(true);
        const oldCode = code;
        const stream = await generateWebsiteCodeStream(currentMessages, code, isThinkingMode || !!selectedElement, iframeErrors, selectedElement?.selector || null);
        setSelectedElement(null); setIframeErrors([]);
        let accumulatedCode = "", firstChunk = true;
        for await (const chunk of stream) {
          if (firstChunk) { setCode(''); firstChunk = false; }
          accumulatedCode += chunk.text;
          setCode(accumulatedCode.replace(/^```html\n|```$/g, '').trim());
          chunk.candidates?.[0]?.groundingMetadata?.groundingChunks?.forEach(c => c.web && citations.set(c.web.uri, c));
        }
        const finalCode = accumulatedCode.replace(/^```html\n|```$/g, '').trim();
        setCode(finalCode);
        
        let summary = "No significant code changes were detected.";
        if (finalCode && oldCode !== finalCode) {
            try {
                summary = await generateChangeSummary(oldCode, finalCode);
                const newVersion: Version = {
                    id: Date.now().toString(),
                    timestamp: Date.now(),
                    code: finalCode,
                    summary: summary,
                };
                setVersions(prevVersions => [newVersion, ...prevVersions].slice(0, 20));

            } catch (e) {
                console.error("Failed to generate change summary:", e);
                summary = "Could not generate a summary of changes, but the website has been updated.";
            }
        }
        
        const finalMessage = summary === "No significant code changes were detected."
            ? "I've processed your request, but there were no major changes to the website code."
            : `I've updated the website. Here's a summary of the changes:\n\n${summary}`;
        
        setMessages(prev => [...prev, { role: 'model', content: finalMessage, citations: Array.from(citations.values()) }]);

      } else {
        setMessages(prev => [...prev, { role: 'model', content: '' }]);
        const stream = await getChatResponseStream(currentMessages);
        let accumulatedText = "";
        for await (const chunk of stream) {
          chunk.candidates?.[0]?.groundingMetadata?.groundingChunks?.forEach(c => c.web && citations.set(c.web.uri, c));
          accumulatedText += chunk.text;
          setMessages(prev => {
              const updated = [...prev];
              if (updated[updated.length - 1]?.role === 'model') updated[updated.length - 1].content = accumulatedText;
              return updated;
          });
        }
        setMessages(prev => {
          const updated = [...prev];
          if (updated[updated.length - 1]?.role === 'model') updated[updated.length - 1].citations = Array.from(citations.values());
          return updated;
        });
      }
    } catch (err) {
      const msg = err instanceof Error ? err.message : 'An unexpected error occurred.';
      setError(msg);
      setMessages(prev => [...prev, { role: 'model', content: `Sorry, I encountered an error: ${msg}`, isError: true }]);
    } finally {
      setIsLoading(false);
      setWasThinking(false);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if ((!prompt.trim() && !image && !video) || isLoading) return;
    executePrompt(prompt, { image, video });
  };
  
  const handleRevertCode = (revertCode: string) => {
    if (window.confirm("Are you sure you want to revert to this version? Your current code changes will be lost.")) {
        const summary = `Reverted to a previous version.`;
        
        const newVersion: Version = {
            id: Date.now().toString(),
            timestamp: Date.now(),
            code: revertCode,
            summary: summary,
        };
        
        setCode(revertCode);
        setMessages(prev => [...prev, { role: 'system', content: summary }]);

        setVersions(prevVersions => [newVersion, ...prevVersions].slice(0, 20));
    }
  };

  const handleBack = () => {
    window.location.hash = '#/dashboard';
  };
  
  if (!isDataLoaded) {
    return (
        <div className="h-screen w-screen bg-gray-900 flex flex-col items-center justify-center gap-4 text-white">
            <Icon name="spinner" className="w-10 h-10" />
            <p className="text-lg text-gray-400">Loading Project...</p>
        </div>
    );
  }

  return (
    <div className="h-screen w-screen p-4 bg-gray-900 flex flex-col gap-4">
      <header className="flex flex-wrap items-center justify-between gap-4 text-white flex-shrink-0">
          <div className="flex items-center gap-4">
              <button onClick={handleBack} title="Back to Dashboard" className="p-2 rounded-md bg-gray-700 text-gray-300 hover:bg-gray-600 hover:text-white transition-colors">
                  <Icon name="arrow-left" className="w-5 h-5"/>
              </button>
              {isEditingName ? (
                  <input
                    ref={nameInputRef}
                    type="text"
                    value={projectName}
                    onChange={handleProjectNameChange}
                    onBlur={handleNameInputBlur}
                    onKeyDown={handleNameInputKeyDown}
                    className="bg-gray-700 border border-gray-600 rounded-md px-2 py-1 text-xl font-bold text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
                  />
              ) : (
                  <div className="flex items-center gap-2">
                    <h1 className="text-xl sm:text-2xl font-bold" title={projectName}>{projectName}</h1>
                    <button onClick={() => setIsEditingName(true)} title="Edit project name" className="p-1 text-gray-400 hover:text-white transition-colors">
                        <Icon name="pencil" className="w-4 h-4"/>
                    </button>
                  </div>
              )}
          </div>
          <div className="flex items-center gap-2 sm:gap-4">
              <div className="hidden md:flex items-center gap-2 text-sm text-gray-300">
                  <Icon name="user" className="w-4 h-4" />
                  <span className="truncate max-w-[150px]" title={user.email || 'User'}>{user.email}</span>
              </div>
              <button
                  onClick={handleSignOut}
                  title="Sign Out"
                  className="p-2 rounded-md bg-gray-700 text-gray-300 hover:bg-red-600 hover:text-white transition-colors"
              >
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                      <path strokeLinecap="round" strokeLinejoin="round" d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1" />
                  </svg>
              </button>
          </div>
      </header>
      
      {error && (
        <div className="bg-red-900 border border-red-700 text-red-200 px-4 py-3 rounded-lg relative flex items-center flex-shrink-0" role="alert">
          <Icon name="warning" className="w-5 h-5 mr-3"/>
          <span className="block sm:inline">{error}</span>
          <button onClick={() => setError(null)} className="absolute top-0 bottom-0 right-0 px-4 py-3">
             <Icon name="x" className="w-5 h-5" />
          </button>
        </div>
      )}
      
      <main className="flex-1 min-h-0 flex flex-col gap-4">
          {showInactivityWarning && (
            <div className="bg-yellow-800 border-b-2 border-yellow-600 text-white px-4 py-2 rounded-lg relative flex items-center justify-between flex-shrink-0" role="alert">
              <div className="flex items-center">
                <Icon name="warning" className="w-5 h-5 mr-3"/>
                <span className="block sm:inline text-sm font-semibold">This project was inactive and scheduled for deletion. Your session has reset its auto-deletion timer.</span>
              </div>
              <button onClick={() => setShowInactivityWarning(false)} className="p-1 rounded-full hover:bg-yellow-700 transition-colors">
                 <Icon name="x" className="w-5 h-5" />
              </button>
            </div>
          )}
          <div className="h-full grid grid-cols-1 lg:grid-cols-3 gap-4 flex-1 min-h-0">
            <div className="lg:col-span-1 min-h-[400px] lg:min-h-0">
                <ChatPanel messages={messages} prompt={prompt} setPrompt={setPrompt} handleSubmit={handleSubmit} isLoading={isLoading} isThinking={wasThinking} isThinkingMode={isThinkingMode} setIsThinkingMode={setIsThinkingMode} image={image} setImage={setImage} video={video} setVideo={setVideo} handleFileUpload={handleFileUpload} selectedElement={selectedElement} setSelectedElement={setSelectedElement} />
            </div>
            <div className="lg:col-span-2 min-h-[400px] lg:min-h-0">
                <CodePreviewPanel 
                  code={code} 
                  setCode={setCode} 
                  iframeRef={iframeRef} 
                  iframeErrors={iframeErrors} 
                  setIframeErrors={setIframeErrors} 
                  onUploadCode={handleUploadCode} 
                  onDownloadCode={handleDownloadCode} 
                  isSelectionModeActive={isSelectionModeActive} 
                  onToggleSelectionMode={handleToggleSelectionMode}
                  versions={versions}
                  onRevert={handleRevertCode}
                />
            </div>
          </div>
      </main>
    </div>
  );
};

export default Editor;
