
export interface GroundingChunk {
  web: {
    uri: string;
    title: string;
  };
}

export interface Message {
  role: 'user' | 'model' | 'system';
  content: string;
  image?: {
    mimeType: string;
    data: string;
  };
  video?: {
    mimeType: string;
    data: string;
  };
  citations?: GroundingChunk[];
  isError?: boolean;
}

// FIX: Add DatabaseTable and DatabaseColumn types for DatabasePanel.
export interface DatabaseColumn {
  id: string;
  name: string;
  type: string;
}

export interface DatabaseTable {
  id: string;
  name: string;
  columns: DatabaseColumn[];
}

export interface Version {
  id: string;
  timestamp: number;
  code: string;
  summary: string;
}

export interface Project {
  id: string;
  name: string;
  lastModified: number;
}